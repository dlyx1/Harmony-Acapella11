package com.harmonyacapella

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.math.pow

class MainActivity : Activity() {
    private var selectedUri: Uri? = null
    private var player: MediaPlayer? = null
    private var semitones = 0
    private lateinit var status: TextView
    private val pickAudio = 10
    private val saveAudio = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF10151D.toInt())
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF2F5F8.toInt())
            setPadding(0, 10, 0, 10)
        }
        page.addView(label("HARMONY ACAPELLA", 23f))
        page.addView(label("Manual vocal pitch workspace • Starter build", 13f))
        val import = Button(this).apply { text = "Import audio"; setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
            }, pickAudio)
        } }
        page.addView(import)
        status = label("No audio selected")
        page.addView(status)
        val preview = Button(this).apply { text = "Preview original"; setOnClickListener { previewAudio() } }
        page.addView(preview)
        page.addView(label("Pitch adjustment: $semitones semitones"))
        val pitch = SeekBar(this).apply {
            max = 24; progress = 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    semitones = p - 12
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    status.text = "Pitch: ${if (semitones > 0) "+" else ""}$semitones semitones"
                }
            })
        }
        page.addView(pitch)
        page.addView(label("Processing mode"))
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Resampling (pitch + speed change)"))
        }
        page.addView(mode)
        page.addView(label("Export applies the selected semitone shift to PCM WAV audio.", 13f))
        page.addView(Button(this).apply {
            text = "Export processed WAV"
            setOnClickListener {
                if (selectedUri == null) {
                    Toast.makeText(this@MainActivity, "Import audio first", Toast.LENGTH_SHORT).show()
                } else {
                    startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "audio/wav"
                        putExtra(Intent.EXTRA_TITLE, "harmony_processed.wav")
                    }, saveAudio)
                }
            }
        })
        page.addView(label("Note: This starter version processes uncompressed 16-bit PCM WAV only. Other formats may preview if Android supports them.", 12f))
        page.addView(label("Multitrack arranging, clip slicing, pitch-shift-with-duration-preserved, and project saving are not implemented yet.", 12f))
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        when (requestCode) {
            pickAudio -> {
                selectedUri = data.data
                contentResolver.takePersistableUriPermission(data.data!!, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                status.text = "Selected: ${data.data!!.lastPathSegment ?: "audio file"}"
            }
            saveAudio -> {
                val uri = data.data!!
                Thread {
                    try {
                        val input = contentResolver.openInputStream(selectedUri!!)!!
                        val wav = WavResampler.process(input, semitones)
                        contentResolver.openOutputStream(uri)?.use { it.write(wav) }
                        runOnUiThread { Toast.makeText(this, "WAV exported", Toast.LENGTH_LONG).show() }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
        }
    }

    private fun previewAudio() {
        val uri = selectedUri ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { it.start() }
                prepareAsync()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot preview this file", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }
}

private object WavResampler {
    fun process(input: InputStream, semitones: Int): ByteArray {
        val bytes = input.use { it.readBytes() }
        require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") {
            "File must be a WAV"
        }
        var pos = 12
        var channels = 0; var sampleRate = 0; var bits = 0; var dataStart = -1; var dataSize = 0
        while (pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4)
            val size = leInt(bytes, pos + 4).coerceAtLeast(0)
            val start = pos + 8
            if (id == "fmt " && size >= 16) {
                channels = leShort(bytes, start)
                sampleRate = leInt(bytes, start + 4)
                bits = leShort(bytes, start + 14)
            } else if (id == "data") {
                dataStart = start; dataSize = minOf(size, bytes.size - start); break
            }
            pos = start + size + (size and 1)
        }
        require(channels in 1..2 && bits == 16 && dataStart >= 0) { "Only mono/stereo PCM 16-bit WAV is supported" }
        val frameBytes = channels * 2
        val frames = dataSize / frameBytes
        require(frames > 1) { "WAV contains no audio" }
        val factor = 2.0.pow(semitones / 12.0)
        val outFrames = (frames / factor).toInt().coerceAtLeast(1)
        val pcm = ByteArray(outFrames * frameBytes)
        for (i in 0 until outFrames) {
            val source = (i * factor).coerceAtMost((frames - 1).toDouble())
            val a = source.toInt()
            val b = minOf(a + 1, frames - 1)
            val frac = source - a
            for (ch in 0 until channels) {
                val va = leShort(bytes, dataStart + a * frameBytes + ch * 2).toShort().toInt()
                val vb = leShort(bytes, dataStart + b * frameBytes + ch * 2).toShort().toInt()
                val value = (va + (vb - va) * frac).toInt().coerceIn(-32768, 32767)
                putShort(pcm, (i * channels + ch) * 2, value)
            }
        }
        val out = ByteArrayOutputStream()
        out.write(bytes, 0, dataStart)
        out.write(pcm)
        val result = out.toByteArray()
        putInt(result, 4, result.size - 8)
        putInt(result, dataStart - 4, pcm.size)
        return result
    }
    private fun leShort(b: ByteArray, p: Int) = (b[p].toInt() and 255) or ((b[p+1].toInt() and 255) shl 8)
    private fun leInt(b: ByteArray, p: Int) = leShort(b,p) or (leShort(b,p+2) shl 16)
    private fun putShort(b: ByteArray, p: Int, v: Int) { b[p] = v.toByte(); b[p+1] = (v shr 8).toByte() }
    private fun putInt(b: ByteArray, p: Int, v: Int) { putShort(b,p,v); putShort(b,p+2,v shr 16) }
}
