# Harmony Acapella

Starter Android project for a manual vocal editing app.

## Current starter features
- Import audio using Android's file picker.
- Preview the original audio using Android MediaPlayer.
- Set a manual semitone offset.
- Export a processed WAV using resampling (pitch and duration/speed change together).
- GitHub Actions workflow builds a debug APK on push or manual dispatch.

## Current limitations
- DSP export supports uncompressed PCM 16-bit WAV, mono or stereo.
- MP3/FLAC and other formats are not decoded for processing in this starter.
- The current pitch algorithm is basic linear-interpolation resampling; it changes pitch and speed together.
- Pitch shifting while preserving duration, multitrack mixing, clip slicing/arrangement, waveform display, piano roll automation, project save/load, undo/redo, and real-time effects are not implemented yet.
- This is an early starter project and has not been device-tested.

## Build
GitHub Actions builds `app/build/outputs/apk/debug/app-debug.apk`.
Open the repository's **Actions** tab, open the latest successful run, then download the `Harmony-Acapella-debug-APK` artifact.
